
package selin;

import javax.swing.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.*;
import java.sql.*;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;

@SuppressWarnings("serial")
public class StudentPanel extends JFrame {
	
	JLabel name,lastname,id,department,gender,image;
	JTextField tname,tlastname,tid,tdepartment,tgender;
	JButton search,previous,next,logout;
	JRadioButton rgender,rdepartment;
	@SuppressWarnings("rawtypes")
	JComboBox cdepartment,cgender;
	ButtonGroup radio;
	JPanel mypanel,popupframe;
	ResultSet rs1, rs, rs2;
	JMenuBar menubar;
	JMenu menu,submenu;
	JMenuItem menuItem,quit,about;
	
	

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StudentPanel(){
		
		mypanel=new JPanel();
		mypanel.setLayout(null);
		mypanel.setSize(304,260);
		mypanel.setPreferredSize(new Dimension(500,400));
		mypanel.setLocation(6,0);
		
		setSize(700,370);
		setLocation(6,6);
		getContentPane().add(mypanel);
		
		menubar = new JMenuBar();
		mypanel.add(menubar);
		menubar.setSize(700,30);
		menubar.setLocation(0,0);
		menubar.setBackground(new Color(150,150,150));
		
		menu = new JMenu("File");
		menu.setBackground(new Color(150,150,150));
		menubar.add(menu);
		
		quit = new JMenuItem("Quit");
		
		menu.add(quit);
		
		quit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0){
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		
		menu = new JMenu("Help");
		menu.setBackground(new Color(150,150,150));
		menubar.add(menu);
		
		about = new JMenuItem("About");
		menu.add(about);
		
		about.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				// TODO Auto-generated method stub
				Object [] arr = {"Close"};
				int n=JOptionPane.showOptionDialog(null, "Student Page. Please enter ID "+"\n"
				        +"Search Student.", "Student Page",JOptionPane.CLOSED_OPTION, JOptionPane.INFORMATION_MESSAGE,null, arr, arr[0]);
			}
		});
		
		
		name = new JLabel();
		name.setSize(167, 51);
		name.setLocation(18, 41);
		name.setText("Student Name");
		
		tname = new JTextField();
		tname.setSize(220,26);
		tname.setLocation(177,53);
		
		lastname = new JLabel();
		lastname.setSize(167,51);
		lastname.setLocation(18,83);
		lastname.setText("Student Lastname");
		
		tlastname = new JTextField ();
		tlastname.setSize(220,26);
		tlastname.setLocation(177,95);
		
		id = new JLabel();
		id.setSize(167,51);
		id.setLocation(18,119);
		id.setText("Student ID");
		
		tid = new JTextField ();
		tid.setSize(220,26);
		tid.setLocation(177,131);
		
		department = new JLabel();
		department.setSize(149, 39);
		department.setText("Department");
		department.setLocation(18,159);
		cdepartment = new JComboBox();
		cdepartment.setSize(165, 20);
		cdepartment.setLocation(177, 169);
		cdepartment.setModel(new DefaultComboBoxModel(new String [] {"Computer Engineering", "EEEN", "BOUN"}));
		
		gender = new JLabel();
		gender.setSize(149,39);
		gender.setText("Gender");
		gender.setLocation(18,191);
		cgender = new JComboBox();
		cgender.setSize(165,20);
		cgender.setLocation(177,201);
		cgender.setModel(new DefaultComboBoxModel(new String []{"Female", "Male"}));
		
		image=new JLabel();
		image.setText("Student Image \n will be here");
		image.setSize(89, 32);
		image.setLocation(24, 10);
		image.setBounds(460,28,240,320);  
		
		search = new JButton("Search");
		search.setSize(101, 26);
		search.setLocation(28, 246);
		previous = new JButton("Next");
		previous.setSize(101, 30);
		previous.setLocation(156, 242);
		next = new JButton("Previous");
		next.setSize(107, 30);
		next.setLocation(290, 242);
		
		mypanel.add(name);
		mypanel.add(tname);
		mypanel.add(lastname);
		mypanel.add(tlastname);
		mypanel.add(id);
		mypanel.add(tid);
		mypanel.add(department);
		mypanel.add(cdepartment);
		mypanel.add(gender);
		mypanel.add(cgender);
		mypanel.add(search);
		mypanel.add(image);
		mypanel.add(previous);
		mypanel.add(next);
		
		setVisible(true);
	
		
		search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				
				
				try{
					JOptionPane.showMessageDialog(popupframe, "Search button will give a JTable of student information without student photos.");
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/PHOTO", "root", "1310");
					Statement stmt1=conn1.createStatement();
					
					int id=Integer.parseInt(tid.getText());				
					rs1 = stmt1.executeQuery("select * from mytable where ID="+id);
					while(rs1.next()){
						
					    cdepartment.setSelectedItem(rs1.getString("Department"));
						cgender.setSelectedItem(rs1.getString("Gender"));
						tname.setText(rs1.getString("Name"));
						tlastname.setText(rs1.getString("LastName"));
						tid.setText(rs1.getString("ID"));
						byte[] img = rs1.getBytes("Photo");
						ImageIcon imager = new ImageIcon(img);
	                    Image im = imager.getImage();
	                    Image myImg = im.getScaledInstance(image.getWidth(), image.getHeight(),Image.SCALE_SMOOTH);
	                    ImageIcon newImage = new ImageIcon(myImg);
	                    image.setIcon(newImage);
	                    
					}
					
					


                    //Resize The ImageIcon
                    
					
				
				
				}catch(Exception e){
					JOptionPane.showMessageDialog(popupframe, "Please check your MySql database connection!!");
				
				}
			}
		   }); 
		
		//aslinda next :)	
				previous.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						
						
						try{
							
							Class.forName("com.mysql.jdbc.Driver").newInstance();
							Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/PHOTO", "root", "1310");
							Statement stmt=conn.createStatement();
							int a = Integer.parseInt(tid.getText()) + 1;
							rs = stmt.executeQuery("select * from mytable where ID="+a);
							rs.next();
							
							cdepartment.setSelectedItem(rs.getString("Department"));
							cgender.setSelectedItem(rs.getString("Gender"));
							tname.setText(rs.getString("Name"));
							tlastname.setText(rs.getString("LastName"));
							tid.setText(String.valueOf((a)));
							
							byte[] img = rs.getBytes("Photo");
							ImageIcon imager = new ImageIcon(img);
		                    Image im = imager.getImage();
		                    Image myImg = im.getScaledInstance(image.getWidth(), image.getHeight(),Image.SCALE_SMOOTH);
		                    ImageIcon newImage = new ImageIcon(myImg);
		                    image.setIcon(newImage);
							

						}catch(Exception e1){
							System.out.println("Student couldnt be found");
						}
					
						
					}
				});
				//aslinda previous :)
				
				next.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
		                 try{
							
							Class.forName("com.mysql.jdbc.Driver").newInstance();
							Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/PHOTO", "root", "1310");
							Statement stmt=conn.createStatement();
							int m = Integer.parseInt(tid.getText()) - 1;
							rs = stmt.executeQuery("select * from mytable where ID="+m);
							rs.next();
							
							cdepartment.setSelectedItem(rs.getString("Department"));
							cgender.setSelectedItem(rs.getString("Gender"));
							tname.setText(rs.getString("Name"));
							tlastname.setText(rs.getString("LastName"));
							tid.setText(String.valueOf((m)));
							
							byte[] img = rs.getBytes("Photo");
							ImageIcon imager = new ImageIcon(img);
		                    Image im = imager.getImage();
		                    Image myImg = im.getScaledInstance(image.getWidth(), image.getHeight(),Image.SCALE_SMOOTH);
		                    ImageIcon newImage = new ImageIcon(myImg);
		                    image.setIcon(newImage);
						
								
				 
							
						}catch(Exception e1){
							System.out.println("Student couldnt be found");
						}
						
						
					}
				});
		   
	
	
	}
	public ImageIcon ResizeImage(String imgPath)
	{ 
		ImageIcon MyImage = new ImageIcon(imgPath);
		Image img = MyImage.getImage();
		Image newImage = img.getScaledInstance(image.getWidth(), image.getHeight(),Image.SCALE_SMOOTH); 
		ImageIcon image = new ImageIcon(newImage);
		return image;
	}
	
	

}
