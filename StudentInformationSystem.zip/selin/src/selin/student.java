package selin;


import javax.swing.*;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;



@SuppressWarnings("serial")
public class student extends JPanel {
	
	private JPanel panel,popupframe;
	private JLabel stu_log, admin_log,sifreadmin,sifrestudent;
	private JTextField sifrea,sifres;
	private JButton stu_enter, adminbutton;
	JMenuBar menubar;
	JMenu menu,submenu;
	JMenuItem menuItem,quit,about;
	
	
	public student(){
		setLayout(null);
		
		
		
		panel=new JPanel();
		panel.setLayout(null);
		panel.setSize(310, 260);
		panel.setLocation(0,0);
		add(panel);
		
		JOptionPane.showMessageDialog(popupframe, "If there is no MySql connection," + "\n" +"you will just receive a JTable of students list on student login page without any photos." + "\n" + "Your admin page wont work!" + "\n" + "Please check your database connection everytime you log in!");
		
		
		menubar = new JMenuBar();
		panel.add(menubar);
		menubar.setSize(316,29);
		menubar.setLocation(0,0);
		menubar.setBackground(new Color(150,150,150));
		
		menu = new JMenu("File");
		menu.setBackground(new Color(150,150,150));
		menubar.add(menu);
		
		quit = new JMenuItem("Quit");
		
		menu.add(quit);
		
		quit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0){
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		
		menu = new JMenu("Help");
		menu.setBackground(new Color(150,150,150));
		menubar.add(menu);
		
		about = new JMenuItem("About");
		menu.add(about);
		
		about.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				// TODO Auto-generated method stub
				Object [] arr = {"Close"};
				int n=JOptionPane.showOptionDialog(null, "Student page password: 12345 "+"\n"
				        +"Admin page password: 1234" + "\n" + "A student information system." , "Log-in Page",JOptionPane.CLOSED_OPTION, JOptionPane.INFORMATION_MESSAGE,null, arr, arr[0]);
			}
		});
		
		stu_log = new JLabel();
		stu_log.setText("Student Log-in");
		stu_log.setSize(100, 50);
		stu_log.setLocation(16, 28);
		
		admin_log = new JLabel();
		admin_log.setText("Admin Log-in");
		admin_log.setSize(100,50);
		admin_log.setLocation(187,28);
		
		sifreadmin = new JLabel();
		sifreadmin.setSize(90, 41);
		sifreadmin.setLocation(187, 68);
		sifreadmin.setText("Password");
		sifrea = new JTextField();
		sifrea.setSize(106, 28);
		sifrea.setLocation(187, 121);
		

		sifrestudent = new JLabel();
		sifrestudent.setSize(100, 50);
		sifrestudent.setLocation(16, 68);
		sifrestudent.setText("Password");
		sifres = new JTextField();
		sifres.setSize(106, 28);
		sifres.setLocation(6, 121);
		
		stu_enter = new JButton();
		stu_enter.setText("Enter");
		stu_enter.setSize(68, 29);
		stu_enter.setLocation(16, 155);
		
		adminbutton = new JButton();
		adminbutton.setText("Enter");
		adminbutton.setSize(68,29);
		adminbutton.setLocation(186,155);
		
		adminbutton.addActionListener (new ActionListener(){
			@SuppressWarnings("unused")
			@Override
			public void actionPerformed(ActionEvent arg0){
				// TODO Auto-generated method stub
				System.out.println("evet");
				if(sifrea.getText().equals("1234")){
				PanelAdmin admin = new PanelAdmin();
				
			}else if(sifrea.getText().equals("")){
				JOptionPane.showMessageDialog(popupframe, "Please enter a password!");
			}
				else {
				JOptionPane.showMessageDialog(popupframe, "Wrong password!!");
				
			}
				sifrea.setText("");
			}
			
		});	
		
		stu_enter.addActionListener (new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0){
				
				// TODO Auto-generated method stub
				if(sifres.getText().equals("12345")){
					StudentPanel up = new StudentPanel();
					panel.setVisible(false);
				}else if(sifres.getText().equals("")){
					JOptionPane.showMessageDialog(popupframe, "Please enter a password!");
				}
				else{
					JOptionPane.showMessageDialog(popupframe, "Wrong password!!");
				}
				sifres.setText("");
			}
		});
	
		panel.add(stu_log);
		panel.add(admin_log);
		panel.add(stu_enter);
		panel.add(adminbutton);
		panel.add(sifreadmin);
		panel.add(sifrea);
		panel.add(sifrestudent);
		panel.add(sifres);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		student s = new student();
		frame.getContentPane().add(s);
		frame.setSize(304, 260);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
	}
	
}
